### we can make set from a list
myList = [1,2,3,4,5]
mySet = set(myList)
print(mySet)

my_set = set([1,2,3,2])
print(my_set)


# we can make set from a tuple
myTpl = (1,2,3,4,5,5,5,5,5)
mySet = set(myTpl)
print(mySet)
