color = ["red","blue","green"]
print(color)

color[0] = "pink"
color[-1] = "purple"
print(color)
