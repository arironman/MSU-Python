myL = [1,2,3]
myL2 = [1,2,3]
myL[1] =myL2
print(myL)
