lst=[]
for x in range(1,1000):
    if x%2 != 0:
        lst.append(x)
print("List is",lst)
