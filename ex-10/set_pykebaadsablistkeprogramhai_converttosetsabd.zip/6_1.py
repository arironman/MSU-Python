lst = ["rom","food","pom"]

del lst[2]

print(lst)
