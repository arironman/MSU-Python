lst = ["Books",1,"Novels",2,"Biography",3]

del lst[::2]

print(lst)
