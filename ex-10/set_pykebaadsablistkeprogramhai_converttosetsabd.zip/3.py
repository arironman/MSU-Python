pink = ("maroon","baby")
purple = ("lilac","lavender")

mix = pink + purple

print(mix)
