lst1 = ["Rom","Strong"]
lst2 = lst1
print(lst1)
print(lst2)

#EXTRAS
rom,pom = [1,2,3],[4,5,6]
print(rom)
print(pom)
