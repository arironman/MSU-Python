lst=["1","2","3","4"]

print(lst*2)



#Multiply numbers within list

import numpy
lst1=[1,2,3]
lst2=[3,2,4]

res1 = numpy.prod(lst1)
res2 = numpy.prod(lst2)

print(res1)
print(res2)
