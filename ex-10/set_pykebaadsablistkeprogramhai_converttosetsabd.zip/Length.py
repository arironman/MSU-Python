lst = ["Romu","Tomu","Domu"]

print(len(lst))

print(max(lst))

print(min(lst))
