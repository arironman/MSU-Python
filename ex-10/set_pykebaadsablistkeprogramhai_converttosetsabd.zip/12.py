romin = [5,4,3,2,1,0]
ind = [0,1,3,5]
rep = [0,0,0,0]

for index in ind:
    romin[ind[index]] = rep[index]
