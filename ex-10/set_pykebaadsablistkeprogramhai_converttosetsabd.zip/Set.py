my_set = {1.0, "Hello", (1, 2, 3)}
print(my_set)


myset = {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
print(myset)


my_sett = {} 
print(my_sett)
print(type(my_sett))


mySet =set()
print(mySet)
print(type(mySet))
