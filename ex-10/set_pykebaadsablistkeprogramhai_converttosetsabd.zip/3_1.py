food=["Pizza","Burger","Noodles"]
sauces=["White","Red","Pink"]

menu = food + sauces

print(menu)
