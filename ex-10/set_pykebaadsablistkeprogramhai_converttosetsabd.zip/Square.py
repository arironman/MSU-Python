lst=[]
for x in range(1,1000):
      x**2
lst.append(x)
print("List is",lst)
