lst = [3,4,2]

print(sum(lst))

print(all(lst))

print(any(lst))

