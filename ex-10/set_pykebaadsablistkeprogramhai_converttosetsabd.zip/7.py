lst = ["Pizza",1,"Pasta",2,"Pizza",3]

del lst[1::2]

print(lst)
