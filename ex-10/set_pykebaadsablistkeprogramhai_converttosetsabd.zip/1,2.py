tpl = ("Rom","Pom")
print(tpl)

for i in tpl:
    print(i)
