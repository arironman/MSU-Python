lst = [1,2,3]

print(1 in lst)

print(4 in lst)

print(4 not in lst)

print(1 not in lst)
