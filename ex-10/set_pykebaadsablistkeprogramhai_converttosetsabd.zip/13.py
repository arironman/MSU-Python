a = [["a","b","c"],["d","e"],["f","g","h"]]

print(a)
print(a[0][1])
print(a[1][1])
print(a[2][0])
