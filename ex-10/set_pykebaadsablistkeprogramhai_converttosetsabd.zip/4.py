tpl = ("Pie","Chart")
print(tpl*4)


