lst=["Rom","Food","1","2"]

for i in lst:
    print(i)
