lst = ["Romin","Alone"]

del lst[:]
