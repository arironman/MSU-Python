lst = ["rom","pom"]

del lst
