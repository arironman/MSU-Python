numlist = [6,3,7,6,0,1,2,4,9]
print(numlist)

print(numlist.count(6))

numlist.append(5)
print(numlist)

numlist.pop(1)
print(numlist)

numlist.remove(4)
print(numlist)

numlist.reverse()
print(numlist)

numlist.sort()
print(numlist)

strlist = ["A","B"]
numlist.extend(strlist)
print(numlist)

numlist.insert(3,4)
print(numlist)

print(numlist.index(1))






