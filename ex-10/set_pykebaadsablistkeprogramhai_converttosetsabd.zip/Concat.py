lst1 = [1,2,3]
lst2 = ["pasta","burger"]
print(lst1,lst2, sep =",")

lst3 = lst1 + lst2
print(lst3)
